import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// The dev server proxies /api and /health to the local backend so the app can
// be developed against `docker compose up` without any CORS configuration.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": { target: "http://localhost:3000", changeOrigin: true },
      "/health": { target: "http://localhost:3000", changeOrigin: true },
      "/ready": { target: "http://localhost:3000", changeOrigin: true },
    },
  },
  build: {
    sourcemap: true,
    outDir: "dist",
  },
});
